wxPython Demo and Samples
=========================

This archive contains a copy of the wxPython Phoenix demo, and also a
collection of small sample applications.

Once you have installed wxPython Phoenix you can run the demo by launching it
from a command line like this::

    cd demo
    python demo.py

Each of the folders in the samples folder contains one or more standalone
applications demonstrating how to use certain features of wxPython.  Examine
the source code in each sample folder to see how to run them and what they do.

