#---------------------------------------------------------------------------
# Name:        etgtools/swig_generator.py
# Author:      Robin Dunn
#
# Created:     3-Nov-2010
# Copyright:   (c) 2010-2018 by Total Control Software
# License:     wxWindows License
#---------------------------------------------------------------------------

"""
Move along, there's nothing to see here... These are not the droids you are
looking for...
"""
